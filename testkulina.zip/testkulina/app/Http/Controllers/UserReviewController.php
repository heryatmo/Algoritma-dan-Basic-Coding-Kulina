<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Carbon\carbon;

use App\Response;
use App\Pengguna;
use App\Produk;
use App\Order;
use App\UserReview;

class UserReviewController extends Controller
{
    protected function showUserReview(){
      $semuaUserReview = UserReview::all();
      return (new Response)->responseSuccess('Berhasil',201,$semuaUserReview);
    }

    protected function createUserReview(Request $request){
      $this->validate($request,[
          'order_id' => 'required',
          'product_id' => 'required',
          'user_id' => 'required',
          'rating' => 'required',
          'review' => 'required',
      ]);
      $user_data = Pengguna::find($request->input('user_id'));
      $order_data = Order::find($request->input('order_id'));
      $product_data = Produk::find($request->input('product_id'));

      try{
        $user_review = new UserReview([
          'order_id' => $order_data->order_id,
          'product_id' => $product_data->product_id,
          'user_id' => $user_data->user_id,
          'rating' => $request->input('rating'),
          'review' => $request->input('review'),
        ]);
        $user_review->save();
         return (new Response)->responseSuccess('Berhasil',201,$user_review);
      }catch (\Exception $e) {
          return (new Response)->responseError('Gagal',404);
      }
    }

    protected function updateUserReview(Request $request, $id){
      $user_review = UserReview::find($id);
      try{
        $review_data = [
          'rating' => $request->get('rating'),
          'review' => $request->get('review'),
        ];
        DB::transaction(function() use ($review_data, $user_review){
           $user_review->update($review_data);
         });
         return (new Response)->responseSuccess('Berhasil',201,$user_review);
      }catch(\Exception $e){
            return response()->json(['errors' => [$e->getMessage()]], 500);
        }
    }

    protected function deleteUserReview($id){
      $user_review = UserReview::find($id);
      if(is_null($user_review)){
        return response()
          ->json(['errors' => ['data not found']],404);
      }
      $user_review->delete();
    }
}
