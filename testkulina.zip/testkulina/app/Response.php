<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Response extends Model
{
  public function responseError($message,$code_status)
  {
      $response = [
          'isSuccess'   => false,
          'codeStatus'  => $code_status,
          'message'     => $message
      ];
      return response()->json($response, 201);
  }

  public function responseSuccess($message,$code_status,$data)
  {
      $response = [
          'isSuccess'   => true,
          'codeStatus'  => $code_status,
          'message'     => $message,
          'data'        => $data
      ];
      return response()->json($response, 201);
  }
}
