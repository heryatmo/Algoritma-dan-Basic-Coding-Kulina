<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produk extends Model
{
  protected $table = 'produk';
  protected $primaryKey = 'product_id';

  protected $fillable = [
    'nama_produk',
  ];
}
