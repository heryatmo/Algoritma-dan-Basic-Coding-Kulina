<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserReviews extends Model
{
  protected $table = 'user_review';
  protected $primaryKey = 'id';

  protected $fillable = [
    'order_id',
    'product_id',
    'user_id',
    'rating',
    'review',
    'created_at',
    'updated_at',
  ];
}
